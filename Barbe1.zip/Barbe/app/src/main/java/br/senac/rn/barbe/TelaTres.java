package br.senac.rn.barbe;

import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class TelaTres extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_tres);
    }

    public void telaquatro(View view) {
        Intent in = new Intent(TelaTres.this, TelaQuatro.class);
        startActivity(in);
    }
}