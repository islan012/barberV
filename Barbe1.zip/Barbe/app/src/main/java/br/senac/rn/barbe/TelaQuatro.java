package br.senac.rn.barbe;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class TelaQuatro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_quatro);
    }
}